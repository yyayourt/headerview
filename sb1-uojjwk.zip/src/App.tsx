import React from 'react';
import { HeaderShowcase } from './components/HeaderShowcase';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderShowcase />
    </div>
  );
}

export default App;