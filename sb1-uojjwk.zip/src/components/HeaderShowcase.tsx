import React, { useState } from 'react';
import { Header1 } from './headers/Header1';
import { Header2 } from './headers/Header2';

interface HeaderInfo {
  id: string;
  name: string;
  description: string;
  component: React.ComponentType;
}

const headers: HeaderInfo[] = [
  {
    id: 'header1',
    name: 'Modern Social Header',
    description: 'A mobile-first header with social media integration and smooth animations',
    component: Header1
  },
  {
    id: 'header2',
    name: 'E-commerce Header',
    description: 'Feature-rich e-commerce header with search and cart functionality',
    component: Header2
  }
];

export const HeaderShowcase = () => {
  const [selectedHeader, setSelectedHeader] = useState<string>(headers[0].id);

  const selectedHeaderInfo = headers.find(h => h.id === selectedHeader);
  const HeaderComponent = selectedHeaderInfo?.component || (() => null);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Selection */}
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Header Showcase</h1>
        <p className="text-gray-600 mb-8">Browse and interact with different header designs</p>
        
        <div className="flex flex-wrap gap-4 mb-8">
          {headers.map((header) => (
            <button
              key={header.id}
              onClick={() => setSelectedHeader(header.id)}
              className={`px-6 py-3 rounded-lg transition-all ${
                selectedHeader === header.id
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
            >
              {header.name}
            </button>
          ))}
        </div>

        {/* Header Info */}
        <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {selectedHeaderInfo?.name}
          </h2>
          <p className="text-gray-600">
            {selectedHeaderInfo?.description}
          </p>
        </div>

        {/* Header Preview */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <HeaderComponent />
          <div className="p-8 bg-gray-50">
            <div className="max-w-2xl mx-auto">
              <h3 className="text-xl font-semibold mb-4">Sample Content</h3>
              <p className="text-gray-600 mb-4">
                This is sample content to demonstrate how the header looks with actual page content.
                Scroll to see sticky header behavior where applicable.
              </p>
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="mb-8">
                  <h4 className="text-lg font-semibold mb-2">Section {i + 1}</h4>
                  <p className="text-gray-600">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                    enim ad minim veniam, quis nostrud exercitation ullamco laboris.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};