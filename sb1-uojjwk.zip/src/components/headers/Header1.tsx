import React, { useState } from 'react';
import { Menu, X, Github, Twitter, Linkedin } from 'lucide-react';

export const Header1 = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="sticky top-0 bg-white shadow-md">
      <nav className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <span className="text-2xl font-bold text-indigo-600">Logo</span>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-indigo-600 transition">Home</a>
            <a href="#" className="text-gray-700 hover:text-indigo-600 transition">About</a>
            <a href="#" className="text-gray-700 hover:text-indigo-600 transition">Services</a>
            <a href="#" className="text-gray-700 hover:text-indigo-600 transition">Contact</a>
            <div className="flex items-center space-x-4">
              <Github className="w-5 h-5 text-gray-600 hover:text-indigo-600 cursor-pointer" />
              <Twitter className="w-5 h-5 text-gray-600 hover:text-indigo-600 cursor-pointer" />
              <Linkedin className="w-5 h-5 text-gray-600 hover:text-indigo-600 cursor-pointer" />
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? (
              <X className="h-6 w-6 text-gray-600" />
            ) : (
              <Menu className="h-6 w-6 text-gray-600" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <div className={`md:hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
          <div className="py-4 space-y-4">
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Home</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">About</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Services</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Contact</a>
            <div className="flex space-x-4 pt-4 border-t">
              <Github className="w-5 h-5 text-gray-600 hover:text-indigo-600 cursor-pointer" />
              <Twitter className="w-5 h-5 text-gray-600 hover:text-indigo-600 cursor-pointer" />
              <Linkedin className="w-5 h-5 text-gray-600 hover:text-indigo-600 cursor-pointer" />
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
};